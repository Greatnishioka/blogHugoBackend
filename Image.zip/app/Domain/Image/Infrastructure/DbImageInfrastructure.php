<?php

namespace App\Domain\Articles\Infrastructure;
use Illuminate\Http\Request;
// Models
use App\Models\User\UserImage;
use App\Models\Articles\ArticleImage;
use App\Models\Images\Image;
// Entities
use App\Domain\Image\Entity\Images\ImageEntity;
use App\Domain\Users\Entity\Users\UserEntity;
// Repositories
use App\Domain\Image\Repository\ImageRepository;
// Others
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use App\Exceptions\Images\CouldNotSaveImageException;
use Illuminate\Support\Str;

class DbImageInfrastructure implements ImageRepository
{

    private Image $image;
    private UserImage $userImage;
    private ArticleImage $articleImage;

    public function __construct(
        Image $image,
        UserImage $userImage,
        ArticleImage $articleImage
    ) {
        $this->image = $image;
        $this->userImage = $userImage;
        $this->articleImage = $articleImage;
    }

    #[\Override]
    public function saveArticleImages(Request $request): array
    {
        // この関数は最終的にはS3に置き換えたいけど、
        // それは自分がRust極めてRustで完璧にバックエンド描けるようになった時に予定しているリプレイスの時のために取っておく🍊

        try {

            // このpre_id付きのディレクトリは、画像の保存先を一時的に指定するためのもの
            // これが残ってる場合はバッチで削除するようにしたいね
            $preNewDirectoryName = now()->format('Ymd-His') . '_pre-id-' . Str::uuid();
            $newDirectory = public_path('articles/' . $preNewDirectoryName);
            $saveDestinationList = [];
            $host = request()->getSchemeAndHttpHost();

            if (!file_exists($newDirectory)) {
                mkdir($newDirectory, 0777, true);
            }

            $files = $request->file('file');
            $topImage = $request->file('topImage');

            // 単一ファイルの場合は配列に変換
            if (!is_array($files)) {
                $files = [$files];
            }

            // リクエスト内にトップイメージが存在する場合は、配列の先頭に追加
            // トップイメージは特別に扱いたい
            if ($topImage) {
                array_unshift($files, $topImage);
            }

            // webp化 + 保存処理
            // 画像の保存先は、/topImage または /articleImagesだけやけど、後々、記事を作成したユーザーのアイコンのリンクも追加するかも
            $imageManager = new ImageManager(new Driver());

            foreach ($files as $index => $image) {
                $img = $imageManager->read($image->getRealPath());

                if ($topImage && $index === 0) {
                    $saveDir = public_path('articles/' . $preNewDirectoryName . '/topImage');
                    if (!file_exists($saveDir)) {
                        mkdir($saveDir, 0777, true);
                    }
                    $fileName = 'topImage.webp';
                } else {
                    $saveDir = public_path('articles/' . $preNewDirectoryName . '/articleImages');
                    if (!file_exists($saveDir)) {
                        mkdir($saveDir, 0777, true);
                    }
                    $fileName = 'articleImage' . $index . '.webp';
                }

                $img->toWebp(90)->save($saveDir . '/' . $fileName);

                $savedImage = $this->image->create([
                    'image_url' => $host . '/' . $preNewDirectoryName . '/iconImage/' . $fileName,
                    'image_name' => $request->input('imageName', ''),
                    'alt_text' => $request->input('altText', ''),
                ]);

                $imageUrl = new ImageEntity(
                    $savedImage->id,
                    $savedImage->image_url,
                    $savedImage->image_name,
                    $savedImage->alt_text,
                );
                $saveDestinationList[$index] = $imageUrl;
            }

            return $saveDestinationList;

        } catch (CouldNotSaveImageException $e) {
            throw new CouldNotSaveImageException($e->getMessage());
        }
    }

    #[\Override]
    public function saveIcon(Request $request, UserEntity $userEntity): ImageEntity
    {
        try {
            $preNewDirectoryName = $userEntity->getUserUuid();
            $newDirectory = public_path('icons/' . $preNewDirectoryName);
            $host = request()->getSchemeAndHttpHost();
            $fileName = 'icon.webp';
            $imageManager = new ImageManager(new Driver());

            if (!file_exists($newDirectory)) {
                mkdir($newDirectory, 0777, true);
            }

            $files = $request->file('file');

            $img = $imageManager->read($files->getRealPath());

            $saveDir = $newDirectory . '/iconImage';
            if (!file_exists($saveDir)) {
                mkdir($saveDir, 0777, true);
            }

            $img->toWebp(90)->save($saveDir . '/' . $fileName);

            $savedImage = $this->image->create([
                'image_url' => $host . '/' . $preNewDirectoryName . '/iconImage/' . $fileName,
                'image_name' => $request->input('imageName', ''),
                'alt_text' => $request->input('altText', ''),
            ]);

            return new ImageEntity(
                $savedImage->id,
                $savedImage->image_url,
                $savedImage->image_name,
                $savedImage->alt_text,
            );

        } catch (CouldNotSaveImageException $e) {
            throw new CouldNotSaveImageException($e->getMessage());

        }
    }
}
