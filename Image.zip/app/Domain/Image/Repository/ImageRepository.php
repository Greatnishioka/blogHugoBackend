<?php

namespace App\Domain\Image\Repository;
use App\Domain\Users\Entity\Users\UserEntity;
use App\Domain\Image\Entity\Images\ImageEntity;
use Illuminate\Http\Request;

interface ImageRepository {

    public function saveArticleImages(Request $request): array;
    public function saveIcon(Request $request, UserEntity $userEntity):ImageEntity;

}
